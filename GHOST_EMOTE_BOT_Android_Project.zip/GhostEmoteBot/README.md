# GHOST EMOTE BOT

A fan-made Android emote catalog and combo planner built with Kotlin + Jetpack Compose.

## Included
- Dark premium home screen
- Demo emote collection with category filters
- Search
- Favorites (in-memory for this starter version)
- Emote preview dialog
- Combo maker

## Important
This app is a visual catalog/planner only. It does not connect to Free Fire, automate gameplay, inject code, or trigger in-game emotes. Replace demo entries with assets you own or are licensed to use.

## Build
1. Install Android Studio (a version supporting Android Gradle Plugin 8.7.3).
2. Open this folder in Android Studio.
3. Let Gradle sync complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

Package: `com.gcg.ghostemotebot`
Minimum Android: 6.0 (API 23)
