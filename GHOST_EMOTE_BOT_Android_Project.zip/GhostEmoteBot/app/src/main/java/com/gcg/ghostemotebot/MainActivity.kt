package com.gcg.ghostemotebot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080D17)
private val Panel = Color(0xFF121E30)
private val Panel2 = Color(0xFF192A40)
private val Cyan = Color(0xFF39D7FF)
private val Muted = Color(0xFF9CB0C8)

data class Emote(
    val id: Int,
    val name: String,
    val category: String,
    val symbol: String,
    val description: String
)

private val demoEmotes = listOf(
    Emote(1, "Victory Dance", "Legendary", "🏆", "A celebration-style emote preview."),
    Emote(2, "Laugh Out", "Rare", "😂", "A playful laugh-style emote preview."),
    Emote(3, "Heart Sign", "Rare", "💖", "A heart-themed emote preview."),
    Emote(4, "Power Pose", "Legendary", "⚡", "A bold pose-style emote preview."),
    Emote(5, "Clap", "Common", "👏", "A simple applause-style emote preview."),
    Emote(6, "Party Time", "Rare", "🎉", "A party-themed emote preview."),
    Emote(7, "Cool Wave", "Common", "👋", "A friendly wave-style emote preview."),
    Emote(8, "Crown Flex", "Legendary", "👑", "A royal-themed emote preview.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GhostApp() }
    }
}

@Composable
fun GhostApp() {
    var selectedTab by remember { mutableStateOf("Home") }
    var selectedCategory by remember { mutableStateOf("All") }
    var search by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(setOf<Int>()) }
    var selectedEmote by remember { mutableStateOf<Emote?>(null) }
    var combo by remember { mutableStateOf(listOf<Emote>()) }

    val categories = listOf("All", "Legendary", "Rare", "Common")
    val visibleEmotes = demoEmotes.filter {
        (selectedCategory == "All" || it.category == selectedCategory) &&
        (it.name.contains(search, ignoreCase = true) || it.category.contains(search, ignoreCase = true)) &&
        (selectedTab != "Favorites" || favorites.contains(it.id))
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Cyan,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(46.dp).background(Panel2, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("👻", fontSize = 25.sp) }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("GHOST EMOTE BOT", fontWeight = FontWeight.Black, fontSize = 17.sp)
                        Text("FREE FIRE EMOTE COLLECTION", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                    Surface(color = Color(0xFF123B35), shape = RoundedCornerShape(50)) {
                        Text("● ONLINE", color = Color(0xFF63E6BE), fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }

                Spacer(Modifier.height(18.dp))
                when (selectedTab) {
                    "Home" -> HomeContent(
                        onBrowse = { selectedTab = "Collection" },
                        favoriteCount = favorites.size,
                        comboCount = combo.size
                    )
                    "Combo" -> ComboContent(combo = combo, onRemove = { item ->
                        combo = combo.filterNot { it.id == item.id }
                    }, onBrowse = { selectedTab = "Collection" })
                    else -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (selectedTab == "Favorites") "Your Favorites" else "Emote Collection",
                                fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Icon(Icons.Default.Tune, contentDescription = null, tint = Cyan)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp)).padding(13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Muted)
                            Spacer(Modifier.width(9.dp))
                            BasicTextField(
                                value = search, onValueChange = { search = it },
                                singleLine = true, modifier = Modifier.weight(1f),
                                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                                decorationBox = { inner ->
                                    if (search.isEmpty()) Text("Search emotes...", color = Muted, fontSize = 14.sp)
                                    inner()
                                }
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            categories.forEach { category ->
                                FilterChip(
                                    selected = selectedCategory == category,
                                    onClick = { selectedCategory = category },
                                    label = { Text(category) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFF16415A),
                                        selectedLabelColor = Cyan
                                    )
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        if (visibleEmotes.isEmpty()) {
                            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                                Text("No emotes found.", color = Muted)
                            }
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(2),
                                contentPadding = PaddingValues(bottom = 90.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(visibleEmotes, key = { it.id }) { emote ->
                                    EmoteCard(
                                        emote = emote,
                                        favorite = favorites.contains(emote.id),
                                        onFavorite = {
                                            favorites = if (favorites.contains(emote.id)) favorites - emote.id else favorites + emote.id
                                        },
                                        onOpen = { selectedEmote = emote }
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                NavigationBar(containerColor = Panel, modifier = Modifier.padding(bottom = 8.dp)) {
                    listOf("Home", "Collection", "Favorites", "Combo").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab; if (tab != "Favorites") selectedCategory = "All" },
                            icon = {
                                Icon(
                                    when (tab) {
                                        "Home" -> Icons.Default.Home
                                        "Favorites" -> Icons.Default.Favorite
                                        else -> Icons.Default.Tune
                                    }, contentDescription = tab
                                )
                            },
                            label = { Text(tab, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan, selectedTextColor = Cyan,
                                indicatorColor = Color(0xFF17364C), unselectedTextColor = Muted,
                                unselectedIconColor = Muted
                            )
                        )
                    }
                }
            }
        }

        selectedEmote?.let { emote ->
            AlertDialog(
                onDismissRequest = { selectedEmote = null },
                containerColor = Panel,
                title = { Text(emote.name, color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text(emote.symbol, fontSize = 64.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("${emote.category} • Preview", color = Cyan, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text(emote.description, color = Muted)
                        Spacer(Modifier.height(8.dp))
                        Text("This is a visual catalog preview, not an in-game action.", color = Muted, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (combo.none { it.id == emote.id }) combo = combo + emote
                        selectedEmote = null
                        selectedTab = "Combo"
                    }) { Text("ADD TO COMBO", color = Cyan) }
                },
                dismissButton = {
                    TextButton(onClick = { selectedEmote = null }) { Text("CLOSE", color = Muted) }
                }
            )
        }
    }
}

@Composable
private fun HomeContent(onBrowse: () -> Unit, favoriteCount: Int, comboCount: Int) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Surface(color = Panel, shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("WELCOME, GHOST!", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(5.dp))
                Text("Your Emote Universe", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Text("Explore, preview and build your own emote combos.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Box(
                    Modifier.fillMaxWidth().height(125.dp)
                        .background(Panel2, RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("👻  ⚡  👑", fontSize = 35.sp)
                        Text("GHOST EMOTE BOT", color = Cyan, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("POWERED BY GCG", color = Muted, fontSize = 9.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(onClick = onBrowse, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg),
                    shape = RoundedCornerShape(13.dp)) {
                    Text("EXPLORE EMOTES", fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("YOUR SPACE", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Favorites", favoriteCount.toString(), "♥", Modifier.weight(1f))
            StatCard("Combo Items", comboCount.toString(), "✦", Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(15.dp)) {
                Text("ABOUT THIS APP", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Text("A fan-made emote catalog and combo planner. It does not connect to or control Free Fire.", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("GAMING COBRA GHOST", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 12.sp)
    }
}

@Composable
private fun StatCard(title: String, value: String, symbol: String, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(symbol, color = Cyan, fontSize = 20.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun EmoteCard(emote: Emote, favorite: Boolean, onFavorite: () -> Unit, onOpen: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emote.category.uppercase(), color = Cyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Icon(
                    if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (favorite) Color(0xFFFF5D83) else Muted,
                    modifier = Modifier.size(20.dp).clickable { onFavorite() }
                )
            }
            Box(
                Modifier.fillMaxWidth().height(90.dp).padding(top = 8.dp)
                    .background(Panel2, RoundedCornerShape(13.dp)).clickable { onOpen() },
                contentAlignment = Alignment.Center
            ) { Text(emote.symbol, fontSize = 42.sp) }
            Spacer(Modifier.height(9.dp))
            Text(emote.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
            Spacer(Modifier.height(7.dp))
            OutlinedButton(onClick = onOpen, modifier = Modifier.fillMaxWidth().height(36.dp),
                contentPadding = PaddingValues(0.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                Text("PREVIEW", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ComboContent(combo: List<Emote>, onRemove: (Emote) -> Unit, onBrowse: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = 10.dp)) {
        Text("COMBO MAKER", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text("Build a personal emote sequence.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        if (combo.isEmpty()) {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("✦", color = Cyan, fontSize = 38.sp)
                    Text("Your combo is empty", fontWeight = FontWeight.Bold)
                    Text("Add emotes from the collection.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onBrowse, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
                        Text("BROWSE EMOTES")
                    }
                }
            }
        } else {
            combo.forEachIndexed { index, emote ->
                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}.", color = Cyan, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(12.dp))
                        Text(emote.symbol, fontSize = 26.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(emote.name, fontWeight = FontWeight.Bold)
                            Text(emote.category, color = Muted, fontSize = 10.sp)
                        }
                        TextButton(onClick = { onRemove(emote) }) { Text("REMOVE", color = Color(0xFFFF718B), fontSize = 10.sp) }
                    }
                }
            }
            Text("Combo is a saved planning list only; it does not trigger actions inside the game.", color = Muted, fontSize = 11.sp)
        }
    }
}
